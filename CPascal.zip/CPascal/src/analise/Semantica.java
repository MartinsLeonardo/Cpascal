/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package analise;

import java.util.ArrayList;
import regrasSemanticas.Regras;
/**
 *
 * @author Leonardo Martins
 */
public class Semantica {
    
    public static void analise(ArrayList ArrayFita){
        System.out.print("\n Estamos em analise semantica \n");
        
        //separar por linhas verificar linha por linha se está dentro da regra semantica;
        Regras.isAtribuicao(ArrayFita);
        Regras.isSimboloInicial(ArrayFita); 
        Regras.isDeclaracao(ArrayFita); 
                
    }
}
